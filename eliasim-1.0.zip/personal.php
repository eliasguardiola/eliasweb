<div id="contenido"> 
    <div id="transparencia-contenido">
    	<div id="textocontenido">
      Egresado de la carrera de <i>Ingeniería en Sistemas de la Información</i> con 22 años, estoy interesado en el desarrollo de software, área en la que me gustaría dedicarme de tiempo completo en un futuro.</br></br>

      Dentro de la rama de los diferentes sistemas operativos he trabajado con GNU/Linux desde 2008 haciendo uso de distintas distribuciones como Ubuntu, Debian, Linux Mint, Arch, Manjaro, openSUSE, Backtrack, Fedora, CentOS, Slackware, entre otras más, siendo mi preferida Manjaro para escritorio y Debian para servidores.</br></br>

      Windows prácticamente lo he usado desde que tuve interés en la informática, no tengo problema para realizar cualquier tarea, mantenimiento o reparación en  el mismo.</br></br>

      Haciendo uso de servidores VPS (Virtual Private Server) he configurado servicios como FTP, SSH, Apache, MySQL, VNC y demás aplicaciones en el entorno Linux.</br></br>

      Otro de mis intereses ha sido el desarrollo web, donde he trabajado con Wordpress y otros CMS como Blogger o Simple Machines Forum. Tengo conocimientos en PHP, HTML y CSS con los que he desarrollado páginas web sencillas haciendo uso de estilos, programación orientada a objetos y bases de datos MySQL.</br></br>

      Tengo mucho interés en la programación y seguir aprendiendo para ser un profesional en esta área, algunos lenguajes que he usado son Java, Python, C++, Bash y Android.</br></br>

    <center><img src="http://elias.im/img/linux.png"> <img src="http://elias.im/img/windows.png"> <img src="http://elias.im/img/android.png"> <img src="http://elias.im/img/dev.png"> <img src="http://elias.im/img/wifi.png"> </center>
  	</div>
  </div>
</div>