<div id="widget1">
    <div id="transparencia-widget">
      <div id="textocontenido">Correo electrónico: </br>
        <img src="http://elias.im/img/mail.png"></br></br>
        Ubicación: </br>
        <img src="http://elias.im/img/world.png"> San Luis Potosí, México.
        </div>
      </div>
</div>