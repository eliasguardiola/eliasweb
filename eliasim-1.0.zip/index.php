<?php
    require 'arbol01.php';
    require 'personal.php';
    require 'arbol02.php';
?>   