<?php
    require 'widget.php';
    require 'footer.php';
?>   